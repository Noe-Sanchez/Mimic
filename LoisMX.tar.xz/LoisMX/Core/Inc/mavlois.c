#include "mavlois.h"

union px4_custom_mode {
  struct {
    uint16_t reserved;
    uint8_t main_mode;
    uint8_t sub_mode;
  };
  uint32_t data;
  float data_float;
  struct {
    uint16_t reserved_hl;
    uint16_t custom_mode_hl;
  };
};

union px4_custom_mode px4_mode;

uint8_t mav_rx_buf[MAVLINK_MAX_PACKET_LEN];
uint8_t mav_tx_buf[MAVLINK_MAX_PACKET_LEN];

uint16_t mav_rx_buf_len = 0;
uint16_t mav_tx_buf_len = 0;
mavlink_message_t mav_rx_msg;
mavlink_message_t mav_tx_msg;
mavlink_command_long_t mav_cmd_long;
int mav_handled_cmd = 0;

mavlink_manual_control_t mav_out_manual_control;

int mav_publish_periodics(UART_HandleTypeDef *huart){
  // First, heartbeat
  // Need to do this here, cause module
  px4_mode.data = 0;
  px4_mode.main_mode = 4; // OFFBOARD
  px4_mode.sub_mode  = 3; // HOLD
  mavlink_msg_heartbeat_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, MAV_TYPE_QUADROTOR, MAV_AUTOPILOT_PX4, 141, px4_mode.data, MAV_STATE_ACTIVE);
  mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
  HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);

  // Next, sys_status
  mavlink_msg_sys_status_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, 268498991,268498991,268498991, 0, 12.4, -1, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
  HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);

  // Last, extended_sys_state
  mavlink_msg_extended_sys_state_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, MAV_VTOL_STATE_UNDEFINED, MAV_LANDED_STATE_IN_AIR);
  mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
  HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);

  return 0;
}

int mav_publish_gps(UART_HandleTypeDef *huart, double lat, double lon){
  // Origin
  mavlink_msg_gps_global_origin_pack_chan(1, 1, MAVLINK_COMM_0, &mav_tx_msg, 25.649033781863928 * 1E7, -100.28982120113689 * 1E7, 0, 0);
  mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
  HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);

  // Actual data
  mavlink_msg_global_position_int_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, 0, lat * 1E7, lon * 1E7, 5000, 5000, 0, 0, 0, 0);
  mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
  HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);

  return 0;
}

int mav_process_incoming(UART_HandleTypeDef *huart){
  // Big boi func, hold on to something
  // Clear buffer first
  memset(mav_rx_buf, 0, MAVLINK_MAX_PACKET_LEN);
  
  // Poll serial if and handle
  HAL_UART_Receive(huart, mav_rx_buf, MAVLINK_MAX_PACKET_LEN, 10);
  for (uint16_t i = 0; i < MAVLINK_MAX_PACKET_LEN; i++){
    if (mavlink_parse_char(MAVLINK_COMM_0, mav_rx_buf[i], &mav_rx_msg, NULL)){
      switch (mav_rx_msg.msgid){
        case MAVLINK_MSG_ID_HEARTBEAT:{
	  break;
        }
        case MAVLINK_MSG_ID_SYS_STATUS:{
          break;
        }
	// The good stuff
        case MAVLINK_MSG_ID_COMMAND_LONG:{
	  mav_handled_cmd = 1;
	  mavlink_msg_command_long_decode(&mav_rx_msg, &mav_cmd_long);
          switch(mav_cmd_long.command){
            case MAV_CMD_REQUEST_MESSAGE:{
	      // Check which request
	      if (mav_cmd_long.param1 == MAVLINK_MSG_ID_AUTOPILOT_VERSION) {							
                const uint8_t * version_bytes = "5b85859";
	        const uint8_t * uid2 = "DanS"; 

        	mavlink_msg_autopilot_version_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, (uint64_t)8602, 33686018, 2, 2, 52, version_bytes, version_bytes, version_bytes, 45, 1, 1, uid2);
		mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
	        HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);
		  
		mav_handled_cmd = 0;

	      }else if (mav_cmd_long.param1 == MAVLINK_MSG_ID_PROTOCOL_VERSION) {

	        mavlink_msg_protocol_version_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, 2, 2, 2, "5b85859", "5b85859");
	        mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
	        HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);
		  
	        mav_handled_cmd = 0;

	      }
	    case MAV_CMD_PREFLIGHT_CALIBRATION: { 
		mav_handled_cmd = 0;
	    }
	      
	    // Send ACK
	    if ( mav_handled_cmd == 0 ){
              mavlink_msg_command_ack_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, mav_cmd_long.command, MAV_RESULT_ACCEPTED, 100, 0, 1, 1);
	    }else{
              mavlink_msg_command_ack_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, mav_cmd_long.command, MAV_RESULT_UNSUPPORTED, 100, 0, 1, 1);
	    }

            mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
	    HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);

	    }
	    break;
	  }
	    
	  case MAVLINK_MSG_ID_MANUAL_CONTROL:{
	    mavlink_msg_manual_control_decode(&mav_rx_msg, &mav_out_manual_control);
	    break;
	  }

	  // Almost there
	  case MAVLINK_MSG_ID_PARAM_REQUEST_READ:{
	    mavlink_param_request_read_t param_request;
	    mavlink_msg_param_request_read_decode(&mav_rx_msg, &param_request);
              
	    mavlink_param_union_t param_value;
            char param_name_to_send[17]; // Buffer for null termination 
            int target_idx = -1;

	    if (param_request.param_index == 0 || strncmp(param_request.param_id, "test", 16) == 0) {
              target_idx = 0;
              strncpy(param_name_to_send, "test", 16);
              param_value.param_int32 = 0;
            } 
            // Param 1: "SYS_AUTOSTART"
            else if (param_request.param_index == 1 || strncmp(param_request.param_id, "SYS_AUTOSTART", 16) == 0) {
              target_idx = 1;
              strncpy(param_name_to_send, "SYS_AUTOSTART", 16);
              //param_value.param_int32 = 51000;
	      param_value.param_int32 = 4001;
            } 
            // Param 2: "MAV_SYS_ID"
            else if (param_request.param_index == 2 || strncmp(param_request.param_id, "MAV_SYS_ID", 16) == 0) {
              target_idx = 2;
              strncpy(param_name_to_send, "MAV_SYS_ID", 16);
              param_value.param_int32 = 1;
            } 
            // Param 3: "SYS_AUTOCONFIG"
            else if (param_request.param_index == 3 || strncmp(param_request.param_id, "SYS_AUTOCONFIG", 16) == 0) {
              target_idx = 3;
             strncpy(param_name_to_send, "SYS_AUTOCONFIG", 16);
              param_value.param_int32 = 0;
            } 
            // Param 4: "COM_RC_IN_MODE"
            else if (param_request.param_index == 4 || strncmp(param_request.param_id, "COM_RC_IN_MODE", 16) == 0) {
              target_idx = 4;
              strncpy(param_name_to_send, "COM_RC_IN_MODE", 16);
              param_value.param_int32 = 0;
            }

	    param_name_to_send[16] = '\0';
            if (target_idx != -1) {
	      mavlink_msg_param_value_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, param_name_to_send, param_value.param_float, MAV_PARAM_TYPE_INT32, 5, target_idx);
	      mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
	      HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);
            }

	    break;
	  }

	  case MAVLINK_MSG_ID_PARAM_REQUEST_LIST:{
	    int param_index = 0;
            int param_count = 5;

	    // Send all params one by one
	    mavlink_msg_param_value_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, "test", 0, MAV_PARAM_TYPE_INT32, param_index, param_count);
            mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
	    HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);
	    HAL_Delay(10);

	    param_index++;
	    mavlink_param_union_t param_value;
	    param_value.param_int32 = 4001;

	    mavlink_msg_param_value_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, "SYS_AUTOSTART", param_value.param_float, MAV_PARAM_TYPE_INT32, param_index, param_count);
	    mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
	    HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);
	    HAL_Delay(10);
	    param_index++;

	    param_value.param_int32 = 1;

	    mavlink_msg_param_value_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, "MAV_SYS_ID", param_value.param_float, MAV_PARAM_TYPE_INT32, param_index, param_count);
            mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
	    HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);
	    HAL_Delay(10);
	    param_index++;

	    param_value.param_int32 = 0;

	    mavlink_msg_param_value_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, "SYS_AUTOCONFIG", param_value.param_float, MAV_PARAM_TYPE_INT32, param_index, param_count);
	    mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
	    HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);
	    HAL_Delay(10);
	    param_index++;

	    param_value.param_int32 = 0;

	    mavlink_msg_param_value_pack_chan(1, MAV_COMP_ID_AUTOPILOT1, MAVLINK_COMM_0, &mav_tx_msg, "COM_RC_IN_MODE", param_value.param_float, MAV_PARAM_TYPE_INT32, param_index, param_count);
            mav_tx_buf_len = mavlink_msg_to_send_buffer(mav_tx_buf, &mav_tx_msg);
	    HAL_UART_Transmit(huart, mav_tx_buf, mav_tx_buf_len, HAL_MAX_DELAY);
	    HAL_Delay(10);

	    break;
	  }

          default:{
	    break;
	  }
        }
      }
    }
  }

  return 0;
}



// Default library ifndefs
//
#ifndef MAVLOIS_H
#define MAVLOIS_H

#include <mavlink.h>
#include "main.h"

// Union def and implementation for mode display
extern union px4_custom_mode;
extern union px4_custom_mode px4_mode;

// Buffers for I/O
extern uint8_t mav_rx_buf[MAVLINK_MAX_PACKET_LEN];
extern uint8_t mav_tx_buf[MAVLINK_MAX_PACKET_LEN];

// Vars for I/O
extern uint16_t mav_rx_buf_len;
extern uint16_t mav_tx_buf_len;
extern mavlink_message_t mav_rx_msg;
extern mavlink_message_t mav_tx_msg;
extern mavlink_command_long_t mav_cmd_long;
extern int mav_handled_cmd;

// Output vars
extern mavlink_manual_control_t mav_out_manual_control;

// Function for publishing periodics (Should run at least at 2-4Hz)
int mav_publish_periodics(UART_HandleTypeDef *huart);

// Functions for publishing specifics
int mav_publish_gps(     UART_HandleTypeDef *huart, double lat, double lon);
//int mav_publish_attitude(UART_HandleTypeDef *huart, float yaw);

// Function for parsing incoming messages and commands
int mav_process_incoming(UART_HandleTypeDef *huart);



#endif // MAVLOIS_H
